var express = require('express');
var logger = require('morgan');
var bodyParser = require('body-parser');


var app = express();

// uncomment after placing your favicon in /public
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var exec = require('child_process').exec;

var CONTENT_TYPES = ['xml', 'json', 'html'];
var DAYTIMES = ['morning', 'evening', 'night'];

app.get('/:d_time', function(req, res, next){
	console.log("Middleware 1");
	var CONTENT_TYPE_INDEX = (req.query.outformat)? CONTENT_TYPES.indexOf(req.query.outformat.toLowerCase()) : undefined;

	if( req.query.outformat && CONTENT_TYPE_INDEX == -1 )
		return res.status(500).end("Content-type specified not understood");

	if( DAYTIMES.indexOf(req.params.d_time.toLowerCase()) == -1)
		return res.status(500).end("daytime should be morning, evening or night");

	if(!req.query.firstname)
		if(CONTENT_TYPE_INDEX == 0){
			res.set('Content-Type', 'application/xml');
			return res.status(500).send(`
				<xml>
					<status> Error </status>
					<message> Firstname is required </message>
				</xml>
				`);
		}
		else if(CONTENT_TYPE_INDEX == 1){
			res.set('Content-Type', 'application/json');
			return res.status(500).send(`
				{
					"status" : "Error",
					"message" : "Firstname is required"
				}
				`);
		}
		
		else { // CONTENT_TYPE_INDEX == 2 || CONTENT_TYPE_INDEX == undefined
			console.log("ERR HTML");
			res.set('Content-Type', 'text/html');
			return res.send(`
				<html>
					<head> Error </head>
					<body> <p style="color : red" id="result"> Firstname is required </p> </body>
					<form method="post">
						<div>Firstname : <input type="text" name="firstname" required /></div>
						<div>Lastname : <input type="text" name="lastname" /></div>
						<div><input type="submit" value="Submit" /></div>
					</form>
				</html>
				`);
		}

	
	var cmd = "bash hello.sh -t="+req.params.d_time+" -f="+req.query.firstname+( (req.query.lastname)?" -l="+req.query.lastname:'' );
	exec(cmd, (error, stdout, stderr) => {
		
		if( CONTENT_TYPE_INDEX == 0 ){
			res.set('Content-Type', 'application/xml');
			res.send(`
				<xml>
					<status> Success </status>
					<message> ${stdout} </message>
				</xml>
				`);
		}
		else if(CONTENT_TYPE_INDEX == 1){
			res.set('Content-Type', 'application/json');
			res.send(`
				{
					"status" : "Success",
					"message" : "${stdout.replace('\n', '')}"
				}
				`);
		}
		else {
			res.set("Content-Type", "text/html");
			res.end(`
				<html>
					<head> Hellow World - Result </head>
					<body> <p style="color : green" id="result"> ${stdout} </p> </body>
					<form method="post">
						<div>Firstname : <input type="text" name="firstname" required /></div>
						<div>Lastname : <input type="text" name="lastname" /></div>
						<div><input type="submit" value="Submit" /></div>
					</form>
				</html>
				`);
		}
	});
});

app.post('/:d_time', function(req, res, next){
	console.log("Middleware 2");
	var CONTENT_TYPE_INDEX = (req.query.outformat)? CONTENT_TYPES.indexOf(req.query.outformat.toLowerCase()) : undefined;

	if( req.query.outformat && CONTENT_TYPE_INDEX == -1 )
		return res.status(500).end("Content-type specified not understood");

	if( DAYTIMES.indexOf(req.params.d_time.toLowerCase()) == -1)
		return res.status(500).end("daytime should be morning, evening or night");

	if(!req.body.firstname)
		if(CONTENT_TYPE_INDEX == 0){
			res.set('Content-Type', 'application/xml');
			return res.status(500).send(`
				<xml>
					<status> Error </status>
					<message> Firstname is required </message>
				</xml>
				`);
		}
		else if(CONTENT_TYPE_INDEX == 1){
			res.set('Content-Type', 'application/json');
			return res.status(500).send(`
				{
					"status" : "Error",
					"message" : "Firstname is required"
				}
				`);
		}
		
		else { // CONTENT_TYPE_INDEX == 2 || CONTENT_TYPE_INDEX == undefined
			console.log("ERR HTML");
			res.set('Content-Type', 'text/html');
			return res.send(`
				<html>
					<head> Error </head>
					<body> <p style="color : red" id="result"> Firstname is required </p> </body>
					<form method="post">
						<div>Firstname : <input type="text" name="firstname" required /></div>
						<div>Lastname : <input type="text" name="lastname" /></div>
						<div><input type="submit" value="Submit" /></div>
					</form>
				</html>
				`);
		}

	
	var cmd = "bash hello.sh -t="+req.params.d_time+" -f="+req.body.firstname+( (req.body.lastname)?" -l="+req.body.lastname:'' );
	exec(cmd, (error, stdout, stderr) => {
		
		if(CONTENT_TYPE_INDEX == 0){
			res.set('Content-Type', 'application/xml');
			res.send(`
				<xml>
					<status> Success </status>
					<message> ${stdout} </message>
				</xml>
				`);
		}
		else if(CONTENT_TYPE_INDEX == 1){
			res.set('Content-Type', 'application/json');
			res.send(`
				{
					"status" : "Success",
					"message" : "${stdout.replace('\n', '')}"
				}
				`);
		}
		else {
			res.set("Content-Type", "text/html");
			res.end(`
				<html>
					<head> Hellow World - Result </head>
					<body> <p style="color : green" id="result"> ${stdout} </p> </body>
					<form method="post">
						<div>Firstname : <input type="text" name="firstname" required /></div>
						<div>Lastname : <input type="text" name="lastname" /></div>
						<div><input type="submit" value="Submit" /></div>
					</form>
				</html>
				`);
		}
	});
});

app.get('/', function(req, res, next){
	console.log("Middleware 3");
	var CONTENT_TYPE_INDEX = (req.query.outformat)? CONTENT_TYPES.indexOf(req.query.outformat.toLowerCase()) : undefined;

	if( req.query.outformat && CONTENT_TYPE_INDEX == -1 )
		return res.status(500).end("Content-type specified not understood");

	if(!req.query.firstname)
		if(CONTENT_TYPE_INDEX == 0){
			res.set('Content-Type', 'application/xml');
			return res.status(500).send(`
				<xml>
					<status> Error </status>
					<message> Firstname is required </message>
				</xml>
				`);
		}
		else if(CONTENT_TYPE_INDEX == 1){
			res.set('Content-Type', 'application/json');
			return res.status(500).send(`
				{
					"status" : "Error",
					"message" : "Firstname is required"
				}
				`);
		}
		
		else { // CONTENT_TYPE_INDEX == 2 || CONTENT_TYPE_INDEX == undefined
			console.log("ERR HTML");
			res.set('Content-Type', 'text/html');
			return res.send(`
				<html>
					<head> Error </head>
					<body> <p style="color : red" id="result"> Firstname is required </p> </body>
					<form method="post">
						<div>Firstname : <input type="text" name="firstname" required /></div>
						<div>Lastname : <input type="text" name="lastname" /></div>
						<div><input type="submit" value="Submit" /></div>
					</form>
				</html>
				`);
		}
	
	var cmd = "bash hello.sh -f="+req.query.firstname+( (req.query.lastname)?" -l="+req.query.lastname:'' );
	exec(cmd, (error, stdout, stderr) => {
		
		if(CONTENT_TYPE_INDEX == 0){
			res.set('Content-Type', 'application/xml');
			res.send(`
				<xml>
					<status> Success </status>
					<message> ${stdout} </message>
				</xml>
				`);
		}
		else if(CONTENT_TYPE_INDEX == 1){
			res.set('Content-Type', 'application/json');
			res.send(`
				{
					"status" : "Success",
					"message" : "${stdout.replace('\n', '')}"
				}
				`);
		}
		else {
			res.set("Content-Type", "text/html");
			res.end(`
				<html>
					<head> Hellow World - Result </head>
					<body> <p style="color : green" id="result"> ${stdout} </p> </body>
					<form method="post">
						<div>Firstname : <input type="text" name="firstname" required /></div>
						<div>Lastname : <input type="text" name="lastname" /></div>
						<div><input type="submit" value="Submit" /></div>
					</form>
				</html>
				`);
		}
	});
});

app.post('/', function(req, res, next){
	console.log("Middleware 4");
	var CONTENT_TYPE_INDEX = (req.query.outformat)? CONTENT_TYPES.indexOf(req.query.outformat.toLowerCase()) : undefined;

	if( req.query.outformat && CONTENT_TYPE_INDEX == -1 )
		return res.status(500).end("Content-type specified not understood");

	if(!req.body.firstname)
		if(CONTENT_TYPE_INDEX == 0){
			res.set('Content-Type', 'application/xml');
			return res.status(500).send(`
				<xml>
					<status> Error </status>
					<message> Firstname is required </message>
				</xml>
				`);
		}
		else if(CONTENT_TYPE_INDEX == 1){
			res.set('Content-Type', 'application/json');
			return res.status(500).send(`
				{
					"status" : "Error",
					"message" : "Firstname is required"
				}
				`);
		}
		
		else { // CONTENT_TYPE_INDEX == 2 || CONTENT_TYPE_INDEX == undefined
			res.set('Content-Type', 'text/html');
			return res.send(`
				<html>
					<head> Error </head>
					<body> <p style="color : red" id="result"> Firstname is required </p> </body>
					<form method="post">
						<div>Firstname : <input type="text" name="firstname" required /></div>
						<div>Lastname : <input type="text" name="lastname" /></div>
						<div><input type="submit" value="Submit" /></div>
					</form>
				</html>
				`);
		}

	
	var cmd = "bash hello.sh -f="+req.body.firstname+( (req.body.lastname)?" -l="+req.body.lastname:'' );
	exec(cmd, (error, stdout, stderr) => {
		
		if(CONTENT_TYPE_INDEX == 0){
			res.set('Content-Type', 'application/xml');
			res.send(`
				<xml>
					<status> Success </status>
					<message> ${stdout} </message>
				</xml>
				`);
		}
		else if(CONTENT_TYPE_INDEX == 1){
			res.set('Content-Type', 'application/json');
			res.send(`
				{
					"status" : "Success",
					"message" : "${stdout.replace('\n', '')}"
				}
				`);
		}
		else {
			res.set("Content-Type", "text/html");
			res.end(`
				<html>
					<head> Hellow World - Result </head>
					<body> <p style="color : green" id="result"> ${stdout} </p> </body>
					<form method="post">
						<div>Firstname : <input type="text" name="firstname" required /></div>
						<div>Lastname : <input type="text" name="lastname" /></div>
						<div><input type="submit" value="Submit" /></div>
					</form>
				</html>
				`);
		}
	});
});



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
